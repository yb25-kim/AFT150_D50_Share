#!/usr/bin/env bash
# SocketCAN 인터페이스를 기동한다. FD 지원 컨트롤러면 FD, 아니면 클래식 CAN 2.0.
#
#   sudo scripts/can_up.sh                      can0 을 1M/4M FD 로
#   sudo scripts/can_up.sh can1                 can1 을 1M/4M FD 로
#   sudo scripts/can_up.sh can0 500000 2000000  비트레이트 직접 지정
#   sudo scripts/can_up.sh vcan0                하드웨어 없이 시험용 가상 CAN
#
# slcan(CANable) 로 쓸 때는 이 스크립트가 필요 없다 — 프로그램이 /dev/ttyACM* 로 직접 연다.
set -u
# 기본 비트레이트는 설정 파일에서 읽는다(있으면). 인자로 주면 그게 우선.
CAN_BITRATE=1000000
CAN_DBITRATE=4000000
# 비트 타이밍은 센서와 맞아야 한다. 아래가 센서 기본 설정값이다.
#   원본:  nom_brp=2  nom_tseg1=34 nom_tseg2=5 nom_sjw=4   (80MHz -> 1M @ 87.5%)
#          data_brp=1 data_tseg1=14 data_tseg2=5 data_sjw=5 (80MHz -> 4M @ 75%)
# 커널 기본 샘플 포인트는 둘 다 75%, 기본 SJW 는 1 이라 지정하지 않으면 값이 달라진다.
# (특히 nominal 87.5% -> 75% 로 어긋나면 CAN FD BRS 송신이 실패한다.)
CAN_SAMPLE_POINT=0.875
CAN_DSAMPLE_POINT=0.75
CAN_SJW=4
CAN_DSJW=5
[ -r /etc/default/aft-can ] && . /etc/default/aft-can

IFACE="${1:-can0}"
BITRATE="${2:-$CAN_BITRATE}"
DBITRATE="${3:-$CAN_DBITRATE}"
SP="$CAN_SAMPLE_POINT"
DSP="$CAN_DSAMPLE_POINT"
SJW="$CAN_SJW"
DSJW="$CAN_DSJW"

if [ "$(id -u)" -ne 0 ]; then
    echo "root 권한이 필요합니다:  sudo $0 $*" >&2
    exit 1
fi

# ---- 가상 CAN: 센서/어댑터 없이 프로그램을 시험할 때 ----
if [[ "$IFACE" == vcan* ]]; then
    modprobe vcan || { echo "vcan 커널 모듈이 없습니다." >&2; exit 1; }
    ip link show "$IFACE" >/dev/null 2>&1 || ip link add dev "$IFACE" type vcan
    ip link set "$IFACE" mtu 72 2>/dev/null || true    # 72 = FD 프레임까지 통과
    ip link set "$IFACE" up
    echo "[OK] $IFACE (가상 CAN) 준비 완료 — 프로그램에서 'vcan ($IFACE, FD)' 선택"
    exit 0
fi

if ! ip link show "$IFACE" >/dev/null 2>&1; then
    echo "[실패] '$IFACE' 인터페이스가 없습니다." >&2
    echo "       · USB 어댑터를 꽂았는지 확인하세요." >&2
    echo "       · 커널 드라이버가 없으면 sudo ./install.sh 를 실행하세요." >&2
    echo "       · 현재 CAN 인터페이스: $(ip -br link show type can 2>/dev/null | awk '{print $1}' | tr '\n' ' ')" >&2
    exit 1
fi

# 설정과 기동을 한 묶음으로 시도한다. 설정은 됐는데 기동이 안 되는 경우가 있어서
# (FD 플래그만 켜지고 data 비트레이트가 없으면 커널이 up 을 거부한다)
# up 까지 성공해야 그 방식을 채택한다.
try_cfg() {
    ip link set "$IFACE" down 2>/dev/null
    ip link set "$IFACE" type can "$@" 2>/dev/null || return 1
    ip link set "$IFACE" up 2>/dev/null || return 1
    return 0
}

# FD 지원 여부를 미리 판별하지 않고 되는 것부터 시도한다.
# (PEAK 의 pcan 드라이버는 FD 어댑터인데도 data_bittiming_const 를 보고하지 않는다.)
# 클래식으로 폴백할 때는 앞선 시도에서 남은 FD 플래그를 fd off 로 반드시 지운다.
if   try_cfg bitrate "$BITRATE" sample-point "$SP" sjw "$SJW" \
             dbitrate "$DBITRATE" dsample-point "$DSP" dsjw "$DSJW" \
             fd on restart-ms 100; then
    MODE="CAN FD  nominal=${BITRATE}@${SP} sjw=${SJW}  data=${DBITRATE}@${DSP} dsjw=${DSJW}"
elif try_cfg bitrate "$BITRATE" sample-point "$SP" \
             dbitrate "$DBITRATE" dsample-point "$DSP" fd on restart-ms 100; then
    MODE="CAN FD  nominal=${BITRATE}@${SP}  data=${DBITRATE}@${DSP}  (SJW 지정 불가 → 기본값)"
elif try_cfg bitrate "$BITRATE" dbitrate "$DBITRATE" fd on restart-ms 100; then
    MODE="CAN FD  nominal=${BITRATE}  data=${DBITRATE}  (샘플포인트 지정 불가 → 커널 기본값, BRS 실패 가능)"
elif try_cfg fd off bitrate "$BITRATE" sample-point "$SP" sjw "$SJW" restart-ms 100; then
    MODE="CAN 2.0 ${BITRATE}@${SP} sjw=${SJW}  (이 드라이버는 ip link 로 FD 설정 불가)"
elif try_cfg fd off bitrate "$BITRATE" sample-point "$SP" restart-ms 100; then
    MODE="CAN 2.0 ${BITRATE}@${SP}  (이 드라이버는 ip link 로 FD 설정 불가)"
elif try_cfg fd off bitrate "$BITRATE" restart-ms 100; then
    MODE="CAN 2.0 ${BITRATE}  (FD·샘플포인트 지정 불가)"
else
    ip link set "$IFACE" down 2>/dev/null
    echo "[실패] $IFACE 기동 실패 — 어댑터가 사용 중이거나 드라이버 문제일 수 있습니다." >&2
    echo "       상세 확인: ip -details link show $IFACE" >&2
    exit 1
fi

ip link set "$IFACE" txqueuelen 1000 2>/dev/null || true
echo "[OK] $IFACE 준비 완료 — $MODE"
ip -br link show "$IFACE"
