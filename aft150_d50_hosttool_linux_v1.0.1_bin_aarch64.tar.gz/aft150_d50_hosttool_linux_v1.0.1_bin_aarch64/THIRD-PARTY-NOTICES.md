# 제3자 소프트웨어 고지 (Third-Party Notices)

이 배포물은 아래 제3자 소프트웨어를 포함하거나 설치 시 내려받습니다.
각 소프트웨어는 원저작자의 라이선스를 따릅니다.

---

## 동봉된 소스 (scripts/drivers/)

### PEAK-System Linux Driver (`peak-linux-driver-9.2.0.tar.gz`)
- 저작권: PEAK-System Technik GmbH
- 라이선스: **GPL-2.0** (커널 드라이버), LGPL (사용자 공간 라이브러리)
  - 배포물 내 `LICENSE.gpl`, `LICENSE.lgpl` 참조
- 출처: https://www.peak-system.com/quick/PCAN-Linux-Driver
- 변경 사항: `scripts/drivers/peak-fd-compat.py` 가 설치 시 `driver/src/pcan_netdev.c` 에
  패치를 적용합니다. 리눅스 커널 5.15.194 미만에서 `data_bittiming_const` 가
  설정되지 않아 CAN FD 를 쓸 수 없는 문제를 해결하기 위한 것으로,
  해당 패치 내용은 `scripts/drivers/peak-fd-compat.py` 에 전문이 들어 있습니다.
  (GPL-2.0 제2조에 따른 변경 사항 고지)

### HMS IXXAT SocketCAN Driver (`ix_usb_can_2.0.520-REL.tgz`)
- 저작권: HMS Technology Center Ravensburg GmbH
- 라이선스: **GPL-2.0** (`SPDX-License-Identifier: GPL-2.0`)
- 출처: https://hmsnetworks.blob.core.windows.net/nlw/docs/default-source/products/ixxat/monitored/pc-interface-cards/socketcan-linux.gz
- 변경 사항: 동봉된 소스는 **원본 그대로**입니다. 설치 시
  `scripts/ixxat_kernel_compat.sh` 가 빌드 직전에 로컬에서 패치를 적용합니다.
  리눅스 커널 6.13 이상에서 커널 API 변경으로 빌드가 실패하는 문제를 해결하기
  위한 것이며, 패치 내용 전문은 해당 스크립트에 들어 있습니다.
  - `can_priv.data_bittiming` → `can_priv.fd.data_bittiming` (커널 6.13~)
  - `.ndo_change_mtu = can_change_mtu` 제거 (CAN XL 도입으로 심볼 제거됨)
  - 대상 커널의 헤더를 검사해 필요한 경우에만 적용하며, 구버전 커널에서는
    원본이 그대로 빌드됩니다.
  (GPL-2.0 제2조에 따른 변경 사항 고지)

> 위 두 드라이버의 완전한 소스 코드는 `scripts/drivers/` 에 그대로 포함되어 있습니다.

---

## 실행파일에 포함된 파이썬 패키지

| 패키지 | 라이선스 |
|---|---|
| Dear PyGui | MIT |
| python-can | LGPL-3.0 |
| pyserial | BSD-3-Clause |

PyInstaller(빌드 시에만 사용)는 GPL-2.0 with a special exception 이며,
이 예외 조항에 따라 PyInstaller 로 만든 실행파일에는 GPL 이 전파되지 않습니다.

> **LGPL 고지 (python-can)**
> `python-can` 은 LGPL-3.0 이며 이 실행파일 안에 포함되어 배포됩니다.
> LGPL-3.0 제4조에 따라, 이 라이브러리를 수정한 버전으로 교체해 실행할 수 있도록
> **재링크에 필요한 자료(해당 버전 소스 및 나머지 부분의 오브젝트)를 요청 시 제공**합니다.
> 문의: AIDIN ROBOTICS. 또는 소스판 배포본을 사용하시면 교체가 자유롭습니다.

---

## 이미지

`image/` 의 로고 및 제품 이미지는 AIDIN ROBOTICS 의 자산입니다.
