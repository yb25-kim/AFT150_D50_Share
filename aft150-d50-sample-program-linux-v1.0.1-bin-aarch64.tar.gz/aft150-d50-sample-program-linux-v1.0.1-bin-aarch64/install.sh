#!/usr/bin/env bash
# AFT150-D50 샘플 프로그램 설치 — 이 스크립트 하나만 실행하면 됩니다.
#
#   sudo ./install.sh                설치 (필요한 CAN 드라이버까지 자동 판별·설치)
#   sudo ./install.sh --no-drivers   CAN 드라이버는 건너뛰고 설치
#   sudo ./install.sh --uninstall    제거
#
# 설치 후에는 ./run.sh 로 실행하고, USB 어댑터는 꽂기만 하면 자동으로 준비됩니다.
set -u
cd "$(dirname "$(readlink -f "$0")")"
DIR="$(pwd)"
S="$DIR/scripts"

if [ "$(id -u)" -ne 0 ]; then
    echo "root 권한이 필요합니다:  sudo ./install.sh" >&2
    exit 1
fi
RUSER="${SUDO_USER:-$(logname 2>/dev/null || echo root)}"

# ─────────────────────────────── 제거 ───────────────────────────────
if [ "${1:-}" = "--uninstall" ]; then
    echo "제거를 시작합니다."
    systemctl list-units 'aft-can@*' --all --no-legend 2>/dev/null | awk '{print $1}' |
        while read -r u; do [ -n "$u" ] && systemctl stop "$u" 2>/dev/null; done
    rm -f /etc/systemd/system/aft-can@.service /etc/udev/rules.d/50-aft150-can.rules \
          /usr/local/bin/aft-can-up /usr/share/applications/aft150-d50.desktop
    systemctl daemon-reload 2>/dev/null || true
    udevadm control --reload-rules 2>/dev/null || true
    rm -rf "$DIR/.venv"
    [ -x "$S/install-pcan-driver.sh" ]  && "$S/install-pcan-driver.sh" uninstall
    [ -x "$S/install-ixxat-driver.sh" ] && "$S/install-ixxat-driver.sh" uninstall
    echo
    echo "제거 완료."
    echo "  남겨 둔 것: /etc/default/aft-can (설정), dialout 그룹 권한, 이 폴더와 CSV 로그"
    exit 0
fi

echo "AFT150-D50 샘플 프로그램 설치"
echo "  위치: $DIR   사용자: $RUSER"

echo
echo "[1/5] 시스템 패키지"
# 배포판마다 패키지 관리자도 패키지 이름도 다르다 → 무엇을 쓰는지 먼저 판별한다.
# 커널 헤더와 빌드 도구는 CAN 드라이버를 빌드할 때 필요하고(기본 설치가 아닌 배포판이 많다),
# dkms 는 커널이 업데이트돼도 드라이버가 자동으로 다시 빌드되게 해 준다.
KVER="$(uname -r)"
if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq || true
    apt-get install -y -qq python3-venv python3-pip can-utils fonts-nanum \
                           build-essential curl dkms "linux-headers-$KVER" \
        || echo "  (일부 실패 — 계속 진행합니다)"
    [ -d /lib/modules/"$KVER"/build ] || apt-get install -y -qq linux-headers-generic >/dev/null 2>&1 || true
elif command -v dnf >/dev/null 2>&1; then
    dnf install -y -q python3 python3-pip can-utils gcc make curl dkms \
                      "kernel-devel-$KVER" google-noto-sans-cjk-fonts \
        || echo "  (일부 실패 — 계속 진행합니다)"
    [ -d /lib/modules/"$KVER"/build ] || dnf install -y -q kernel-devel >/dev/null 2>&1 || true
elif command -v yum >/dev/null 2>&1; then
    yum install -y -q python3 python3-pip can-utils gcc make curl dkms "kernel-devel-$KVER" \
        || echo "  (일부 실패 — 계속 진행합니다)"
    [ -d /lib/modules/"$KVER"/build ] || yum install -y -q kernel-devel >/dev/null 2>&1 || true
elif command -v pacman >/dev/null 2>&1; then
    # 아치 계열은 실행 중인 커널에 맞는 헤더 패키지를 고른다(linux / linux-lts / linux-zen).
    case "$KVER" in
        *-lts)  KHDRPKG=linux-lts-headers ;;
        *-zen)  KHDRPKG=linux-zen-headers ;;
        *)      KHDRPKG=linux-headers ;;
    esac
    pacman -Sy --noconfirm --needed python python-pip can-utils base-devel curl dkms \
                                    "$KHDRPKG" noto-fonts-cjk >/dev/null 2>&1 \
        || echo "  (일부 실패 — 계속 진행합니다)"
elif command -v zypper >/dev/null 2>&1; then
    zypper --non-interactive install -y python3 python3-pip canutils gcc make curl dkms \
                                        kernel-devel kernel-default-devel >/dev/null 2>&1 \
        || echo "  (일부 실패 — 계속 진행합니다)"
else
    echo "  알 수 없는 배포판 — 아래를 직접 설치한 뒤 다시 실행하세요:"
    echo "    python3(venv, pip), can-utils, gcc, make, curl, dkms, 커널 헤더($KVER)"
fi

if [ -d /lib/modules/"$KVER"/build ]; then
    echo "  커널 헤더 확인됨"
else
    echo "  [경고] 커널 헤더 없음 — CAN 드라이버 빌드가 필요한 경우 실패합니다"
fi
if command -v dkms >/dev/null 2>&1; then
    echo "  DKMS 사용 가능 — 커널 업데이트 후에도 CAN 드라이버가 유지됩니다"
else
    echo "  [참고] DKMS 없음 — 커널 업데이트 후 sudo ./install.sh 를 다시 실행하세요"
fi

echo
echo "[2/5] 파이썬 의존성"
# 실행파일판 배포본에는 파이썬과 의존성이 실행파일 안에 들어 있다 → 설치할 것이 없다.
if ls aft150-d50-sample-program-linux-* >/dev/null 2>&1; then
    echo "  건너뜀 — 실행파일판이라 파이썬 설치가 필요 없습니다"
elif sudo -u "$RUSER" python3 -m venv .venv >/dev/null 2>&1; then
    sudo -u "$RUSER" .venv/bin/python -m pip install --upgrade -q pip
    sudo -u "$RUSER" .venv/bin/python -m pip install -q -r "$S/requirements.txt" \
        && echo "  .venv 에 설치 완료"
else
    echo "  venv 생성 실패 → 사용자 영역(--user)에 설치합니다"
    sudo -u "$RUSER" python3 -m pip install -q --user -r "$S/requirements.txt" \
        || sudo -u "$RUSER" python3 -m pip install -q --user --break-system-packages -r "$S/requirements.txt" \
        || { echo "  [실패] 파이썬 의존성 설치 실패" >&2; exit 1; }
fi

echo
echo "[3/5] CAN 드라이버"
if [ "${1:-}" = "--no-drivers" ]; then
    echo "  건너뜀 (--no-drivers)"
else
    # 파이프(| sed)를 거치면 종료 상태가 sed 의 것이 되어 설치 실패를 놓친다 → pipefail 로 막는다.
    set -o pipefail

    # 커널에 없는 것만 빌드·설치한다. 이미 있으면 아무것도 하지 않는다.
    if modinfo pcan >/dev/null 2>&1 || modinfo peak_usb >/dev/null 2>&1; then
        echo "  PCAN  : 이미 사용 가능"
    else
        echo "  PCAN  : 커널에 없음 → 설치합니다"
        "$S/install-pcan-driver.sh" 2>&1 | sed 's/^/    /' \
            || echo "    [경고] PCAN 드라이버 설치 실패 (다른 어댑터는 계속 사용 가능)"
    fi

    # IXXAT 는 어떤 배포판에도 포함돼 있지 않아 항상 직접 빌드해야 한다.
    # DKMS 를 쓸 수 있는데 등록이 안 돼 있으면, 지금 모듈이 있더라도 커널 업데이트 때
    # 사라지므로 다시 설치해서 DKMS 에 등록해 둔다.
    IXXAT_OK=0
    if modinfo ix_usb_can >/dev/null 2>&1; then
        if command -v dkms >/dev/null 2>&1; then
            dkms status ix_usb_can 2>/dev/null | grep -q . && IXXAT_OK=1
        else
            IXXAT_OK=1
        fi
    fi
    if [ "$IXXAT_OK" = 1 ]; then
        echo "  IXXAT : 이미 사용 가능"
    else
        echo "  IXXAT : 설치합니다"
        "$S/install-ixxat-driver.sh" 2>&1 | sed 's/^/    /' \
            || echo "    [경고] IXXAT 드라이버 설치 실패 (다른 어댑터는 계속 사용 가능)"
    fi

    echo "  CANable: 커널 드라이버 불필요"
    set +o pipefail
fi

echo
echo "[4/5] 자동 기동 + 권한 + 아이콘"
install -m 755 "$S/can-up.sh" /usr/local/bin/aft-can-up
install -m 644 "$S/50-aft150-can.rules" /etc/udev/rules.d/50-aft150-can.rules
install -m 644 "$S/aft-can@.service" /etc/systemd/system/aft-can@.service
[ -e /etc/default/aft-can ] || install -m 644 "$S/aft-can.default" /etc/default/aft-can
systemctl daemon-reload 2>/dev/null || true
udevadm control --reload-rules 2>/dev/null || true
usermod -aG dialout "$RUSER"
sed "s|INSTALL_DIR|$DIR|g" "$S/aft150-d50.desktop" > /usr/share/applications/aft150-d50.desktop
chmod 644 /usr/share/applications/aft150-d50.desktop
echo "  USB 어댑터를 꽂으면 자동으로 준비됩니다 (재부팅 후에도)"
echo "  $RUSER 를 dialout 그룹에 추가 / 메뉴 아이콘 등록"

echo
echo "[5/5] 지금 꽂혀 있는 어댑터 기동"
FOUND=0
for i in $(ip -br link show type can 2>/dev/null | awk '{print $1}'); do
    # 보드 내장 CAN 은 배선이 없을 수 있으니 USB 어댑터만 자동 기동한다.
    if [ -e "/sys/class/net/$i/device/driver" ] &&
       readlink -f "/sys/class/net/$i/device" | grep -q usb; then
        "$S/can-up.sh" "$i" 2>&1 | sed 's/^/  /'
        FOUND=1
    fi
done
[ "$FOUND" = "1" ] || echo "  (USB CAN 어댑터가 연결되어 있지 않습니다)"

echo
echo "════════════════════════════════════════════════════"
echo " 설치 완료"
echo "════════════════════════════════════════════════════"
echo "  실행     :  ./run.sh        (또는 메뉴 아이콘)"
echo "  진단     :  ./run.sh --check"
echo "  제거     :  sudo ./install.sh --uninstall"
echo
echo "  ※ dialout 권한 적용을 위해 한 번 로그아웃했다 다시 로그인하세요."
