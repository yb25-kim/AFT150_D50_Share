#!/usr/bin/env bash
# 프로그램 실행.
#   실행파일판 — 같은 폴더의 aft150-d50-sample-program-linux-* 를 바로 실행한다.
#   소스판     — .venv 가 있으면 그걸로, 없으면 시스템 파이썬으로 실행한다.
cd "$(dirname "$(readlink -f "$0")")"

BIN="$(ls aft150-d50-sample-program-linux-* 2>/dev/null | head -1)"
if [ -n "$BIN" ] && [ -x "$BIN" ]; then
    exec "./$BIN" "$@"
elif [ -x .venv/bin/python ]; then
    exec .venv/bin/python aft150-d50-sample-program-v1.0.1.py "$@"
else
    exec python3 aft150-d50-sample-program-v1.0.1.py "$@"
fi
